A Pen created at CodePen.io. You can find this one at http://codepen.io/boylett/pen/uCkms.

 Built this awesome dribbble by Sebastian Beltz http://dribbble.com/shots/1408634-Music-Player