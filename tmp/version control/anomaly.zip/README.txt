A Pen created at CodePen.io. You can find this one at http://codepen.io/rauldronca/pen/vKzvYN.

 // Updated

Created for codepad.co - https://codepad.co/snippet/aSiGmsBE
